//: A SpriteKit based Playground

import PlaygroundSupport
import SpriteKit


enum Direction {
    
    case UP
    case DOWN
    case LEFT
    case RIGHT
    case STAY
    
    
}

class PacCharacter {
    var appearance: Character
    var row: Int
    var col: Int
    
    init(row: Int, col: Int, appearance: Character) {
        self.row = row;
        self.col = col;
        self.appearance = appearance;
    }
    init () {
        row = 0
        col = 0
        appearance = "?"
    }
    func getRow() ->Int {
        return self.row;
    }
    
    func getCol() ->Int {
        return self.col;
    }
    
    func getAppearance() ->Character {
        return self.appearance;
    }
    
    func setPosition(row:Int, col:Int) {
        self.row = row;
        self.col = col;
    }
    
    func setAppearance(appearance:Character) {
        self.appearance = appearance;
    }
}

class Board {
    
    // FIELD
    let GRID_SIZE: Int
    
    var grid: [[Character]]       // String Representation of Pac-man Game Board
    var visited: [[Bool]]    // Record of where Pac-man has visited
    var pacman: PacCharacter // Pac-man that user controls
    var ghosts: [PacCharacter] // 4 Ghosts that controlled by the program
    var score: Int              // Score Recorded for the gamer
    
    
    
    func CheckDirX(direction: Direction) -> Int {
        var dirx: Int
        var diry: Int
        switch direction{
        case .UP: do {
            dirx = -1
            diry = 0
            }
        case .DOWN: do {
            dirx = 1
            diry = 0
            }
        case .LEFT: do {
            dirx = 0
            diry = -1
            }
        case .RIGHT: do {
            dirx = 0
            diry = 1
            }
            
        case .STAY:
            dirx = 0
        }
        return dirx
    }
    
    func CheckDirY(direction: Direction) -> Int {
        var dirx :Int
        var diry: Int
        switch direction{
        case .UP: do {
            dirx = -1
            diry = 0
            }
        case .DOWN: do {
            dirx = 1
            diry = 0
            }
        case .LEFT: do {
            dirx = 0
            diry = -1
            }
        case .RIGHT: do {
            dirx = 0
            diry = 1
            }
            
        case .STAY:
            diry = 0
        }
        return diry
    }
    
    /*
     * Constructor
     *
     * <p> Description: TODO
     *
     * @param:  TODO
     * @return: TODO
     */
    init(size: Int) {
        self.GRID_SIZE = size;
        self.grid = Array(repeating: Array(repeating: "?", count: GRID_SIZE), count: GRID_SIZE)
        self.visited = Array(repeating: Array(repeating: false, count: GRID_SIZE), count: GRID_SIZE)
        self.score = 0;
        
        self.pacman = PacCharacter(row: GRID_SIZE/2, col: GRID_SIZE/2, appearance: "P");
        self.ghosts = Array(repeating: PacCharacter(), count: 4);
        self.ghosts[0] = PacCharacter(          row: 0,           col: 0, appearance: "G");
        self.ghosts[1] = PacCharacter(          row: 0, col: GRID_SIZE-1, appearance: "G");
        self.ghosts[2] = PacCharacter(row: GRID_SIZE-1,           col: 0, appearance: "G");
        self.ghosts[3] = PacCharacter(row: GRID_SIZE-1, col: GRID_SIZE-1, appearance: "G");
        
        setVisited(x:GRID_SIZE/2, y:GRID_SIZE/2);
        
        refreshGrid();
    }
    
    
    func getScore() ->Int {
        return score;
    }
    
    
    func getGrid() ->[[Character]]  {
        return grid;
    }
    
    func setVisited(x:Int, y:Int) {
        if (x < 0 || y < 0 || x >= GRID_SIZE || y > GRID_SIZE){
            return;
        }
        
        visited[x][y] = true;
    }
    
    func refreshGrid() {
        let i = 0
        let j = 0
        for i in 0...GRID_SIZE {
            for j in 0...GRID_SIZE {
                if (!visited[i][j]) {
                    grid[i][j] = "*";
                }
                else {
                    grid[i][j] = " ";
                }
                
            }
        }
        grid[pacman.getRow()][pacman.getCol()] = pacman.getAppearance();
        for ghost in ghosts {
            if (pacman.getRow() == ghost.getRow() && pacman.getCol() == ghost.getCol()) {
                grid[ghost.getRow()][ghost.getCol()] = "X";
            }
                
            else {
                grid[ghost.getRow()][ghost.getCol()] = ghost.getAppearance();
            }
        }
        
    }
    
    
    func canMove(direction:Direction) ->Bool {
        // if (direction == nil) {
        // return false;
        //}
        // Calculate Coordinate after Displacement
        let dirx = CheckDirX(direction: direction)
        let pacmanRow = pacman.getRow() + dirx;
        let pacmanCol = pacman.getCol() + CheckDirY(direction:direction);
        
        return pacmanRow >= 0 && pacmanRow < GRID_SIZE && pacmanCol >= 0 && pacmanCol < GRID_SIZE;
    }
    
    
    func move(direction:Direction) {
        // Calculate Coordinate after Displacement
        var pacmanRow = pacman.getRow() + CheckDirX(direction:direction);
        var pacmanCol = pacman.getCol() + CheckDirY(direction:direction);
        
        pacman.setPosition(row:pacmanRow, col:pacmanCol);
        if (!visited[pacmanRow][pacmanCol]) {
            score += 10;
            visited[pacmanRow][pacmanCol] = true;
        }
        
        for ghost in ghosts {
            ghostMove(ghost:ghost);
        }
        
        refreshGrid();
    }
    
    
    func isGameOver() -> Bool {
        var pacmanRow = pacman.getRow();
        var pacmanCol = pacman.getCol();
        
        for ghost in ghosts{
            if (ghost.getRow() == pacmanRow && ghost.getCol() == pacmanCol){
                return true;
            }
        }
        
        
        
        return false;
        
    }
    
    // Monster always move towards Pac-man
    func ghostMove(ghost:PacCharacter) -> Direction{
        var pacmanRow = pacman.getRow();
        var pacmanCol = pacman.getCol();
        
        var ghostRow = ghost.getRow();
        var ghostCol = ghost.getCol();
        
        var rowDist = abs(ghostRow - pacmanRow);
        var colDist = abs(ghostCol - pacmanCol);
        
        if (rowDist == 0 && colDist > 0) {
            if (ghostCol - pacmanCol > 0) {
                ghost.setPosition(row:ghostRow, col:ghostCol - 1);
                return Direction.LEFT;
            } else { // ghostCol - pacmanCol < 0
                ghost.setPosition(row:ghostRow, col:ghostCol + 1);
                return Direction.RIGHT;
            }
        }
        else if (rowDist > 0 && colDist == 0 ) {
            if (ghostRow - pacmanRow > 0) {
                ghost.setPosition(row:ghostRow - 1, col:ghostCol);
                return Direction.UP;
            } else { // ghostRow - pacmanRow < 0
                ghost.setPosition(row:ghostRow + 1, col:ghostCol);
                return Direction.DOWN;
            }
        }
        else if (rowDist == 0 && colDist == 0) {
            return Direction.STAY;
        }
        else {
            if (rowDist < colDist) {
                if (ghostRow - pacmanRow > 0) {
                    ghost.setPosition(row:ghostRow - 1, col:ghostCol);
                    return Direction.UP;
                } else { // ghostRow - pacmanRow < 0
                    ghost.setPosition(row:ghostRow + 1, col:ghostCol);
                    return Direction.DOWN;
                }
            } else {
                if (ghostCol - pacmanCol > 0) {
                    ghost.setPosition(row:ghostRow, col:ghostCol - 1);
                    return Direction.LEFT;
                } else { // ghostCol - pacmanCol < 0
                    ghost.setPosition(row:ghostRow, col:ghostCol + 1);
                    return Direction.RIGHT;
                }
            }
        }
        
    }
    
    
    
    /*func toString() -> String{
     
     var outputString = String();
     outputString+=(String.init(format: self.score as! String , "Score: %d\n"));
     var row = 0
     var col = 0
     for row in 0...GRID_SIZE-1
     {
     for col in 0...GRID_SIZE-1 {
     outputString+="  ";
     outputString += grid[row][col];
     }
     
     outputString+="\n";
     }
     return outputString
     
     }*/
    
    
    
    
}


class GameScene: SKScene {
    
    private var label : SKLabelNode!
    private var spinnyNode : SKShapeNode!
    let player = SKSpriteNode(imageNamed: "pacman_right.png")
    let board = Board(size: 10)
    let ghost = SKSpriteNode(imageNamed: "pinky_left.png")
    let pacdot = SKSpriteNode(imageNamed: "pac_dot")
    let eatendot = SKSpriteNode(imageNamed: "pacdot_eaten")
    private var nodes =  [[SKNode]]()
    //var tiles = SKTileMapNode()
    
    override func didMove(to view: SKView) {
        backgroundColor = SKColor.black
        var i = 0
        var j = 0
        
        for i in 0...9 {
            for j in 0...9{
                if (board.grid[i][j]=="P") {
                    nodes[i][j].addChild(player)
                    scene?.addChild(nodes[i][j])
                }
                else if board.grid[i][j]=="G" {
                    nodes[i][j].addChild(ghost)
                    scene?.addChild(nodes[i][j])
                }
                else if board.grid[i][j]=="*" {
                    nodes[i][j].addChild(pacdot)
                    scene?.addChild(nodes[i][j])
                }
                else {
                    nodes[i][j].addChild(eatendot)
                    scene?.addChild(nodes[i][j])
                }
            }
        }
        // Create shape node to use during mouse interaction
        
        
    }
    
    @objc static override var supportsSecureCoding: Bool {
        // SKNode conforms to NSSecureCoding, so any subclass going
        // through the decoding process must support secure coding
        get {
            return true
        }
    }
    
    func touchDown(atPoint pos : CGPoint) {
        guard let n = spinnyNode.copy() as? SKShapeNode else { return }
        
        n.position = pos
        n.strokeColor = SKColor.green
        addChild(n)
    }
    
    func touchMoved(toPoint pos : CGPoint) {
        guard let n = self.spinnyNode.copy() as? SKShapeNode else { return }
        
        n.position = pos
        n.strokeColor = SKColor.blue
        addChild(n)
    }
    
    func touchUp(atPoint pos : CGPoint) {
        guard let n = spinnyNode.copy() as? SKShapeNode else { return }
        
        n.position = pos
        n.strokeColor = SKColor.red
        addChild(n)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchDown(atPoint: t.location(in: self)) }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchMoved(toPoint: t.location(in: self)) }
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchUp(atPoint: t.location(in: self)) }
    }
    
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { touchUp(atPoint: t.location(in: self)) }
    }
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
    }
}

// Load the SKScene from 'GameScene.sks'
let sceneView = SKView(frame: CGRect(x:0 , y:0, width: 640, height: 480))
if let scene = GameScene(fileNamed: "GameScene") {
    // Set the scale mode to scale to fit the window
    scene.scaleMode = .aspectFill
    
    // Present the scene
    sceneView.presentScene(scene)
}

PlaygroundSupport.PlaygroundPage.current.liveView = sceneView

//
//  Unsaved Xcode Document.swift
//
//
//  Created by Minjing Shi on 3/24/19.
//








